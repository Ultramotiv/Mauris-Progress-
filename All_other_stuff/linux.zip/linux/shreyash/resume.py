import Robot

robot = Robot.RPC('192.168.58.2')

err = robot.ResumeMotion()
print("Resume:",err)