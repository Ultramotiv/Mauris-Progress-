from fairino import Robot
import time
# A connection is established with the robot controller. A successful connection returns a robot object

class ASD:
    def __init__(self):
        print("AAA")
    def Mode(self):
        print("222")





