from Test1 import ASD
class BSD:
    def __init__(self,robot):
        self.robot = robot
        print("BBB")
    def Mode(self):
        self.robot.Mode()