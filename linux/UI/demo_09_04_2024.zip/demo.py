# -*- coding: utf-8 -*-
"""
PyQt6 UI for robot control using Tabs.

Features:
- Connect Tab: Connects robot, handles Drag Teach via button.
- Record Tab: Handles Drag Teach via button, records TPD, logs to CSV.
- Playback Tab: Selects TPD from CSV, sets global speed via slider,
  moves to start, implicitly starts playback, monitors completion via QTimer.
- Drag Teach: Enabled when 'Connect' OR 'Record' buttons are active.
- State Management: UI elements updated based on connection and activity.
- Error Handling: Uses QMessageBox.

Last Change: Added debug print for trajectory_combo creation.
"""

import sys
import time
import csv
from datetime import datetime
import os

# --- Robot Import ---
try:
    # IMPORTANT: Make sure the Robot library is accessible in your environment
    import Robot
    print("Successfully imported Robot library.")
    # Check for necessary methods instead of a single play command
    REQUIRED_METHODS = [
        "LoadTPD", "GetTPDStartPose", "MoveL", "SetSpeed",
        "GetRobotMotionDone", "StopMotion", "PauseMotion", "ResumeMotion",
        "DragTeachSwitch", "SetTPDParam", "SetTPDStart", "SetWebTPDStop"
        ] # Add any other essential methods used
except ImportError:
    print("-----------------------------------------------------------")
    print("FATAL ERROR: 'Robot' library not found.")
    print("-----------------------------------------------------------")
    # Dummy Robot for UI testing without library
    class Robot:
        class RPC:
            def __init__(self, ip): print(f"Warning: Dummy Robot created for IP {ip}"); raise ConnectionError("Dummy Robot")
            def __getattr__(self, name):
                print(f"Warning: Dummy Robot - Called missing method: {name}")
                if name in ["LoadTPD", "MoveL", "SetSpeed", "SetTPDParam", "SetTPDStart", "SetWebTPDStop", "StopMotion", "PauseMotion", "ResumeMotion", "DragTeachSwitch"]: return lambda *a, **k: 0
                if name == "GetTPDStartPose": return lambda *a, **k: (0, [0.0]*6)
                if name == "GetRobotMotionDone": return lambda *a, **k: (0, 1)
                return lambda *a, **k: None
    print("Warning: Using Dummy Robot class as real library not found.")
    REQUIRED_METHODS = [] # Skip checks if using dummy
# --- End Robot Import ---

from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QGridLayout, QMessageBox,
    QInputDialog, QLineEdit, QTabWidget, QVBoxLayout, QLabel, QSizePolicy, QHBoxLayout,
    QComboBox, QSlider
)
from PyQt6.QtGui import QIcon, QFont
from PyQt6.QtCore import QSize, pyqtSlot, Qt, QTimer # Added QTimer & Qt

# --- Configuration ---
ROBOT_IP = '192.168.58.2'
TRAJECTORY_CSV_FILE = 'trajectory_log.csv'
RECORDING_PERIOD = 4
RECORDING_DI = 0
RECORDING_DO = 0
PLAYBACK_BLEND = 1
PLAYBACK_MONITOR_INTERVAL = 250 # ms

DRAG_TEACH_CONTROLLERS = {"ConnecttoPatient", "RecordExercise"}

class RobotControlTabsApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Robot Control Interface - Tabs")
        self.setGeometry(300, 200, 650, 450)

        # State Flags & Data
        self.robot = None
        self._is_recording = False
        self._is_playing = False
        self._is_paused = False
        self.current_recording_name = None
        self.current_playback_name = None

        # Playback Monitoring Timer
        self.playback_monitor_timer = QTimer(self)
        self.playback_monitor_timer.setInterval(PLAYBACK_MONITOR_INTERVAL)
        self.playback_monitor_timer.timeout.connect(self._check_playback_status)

        # UI Element References (Initialized to None)
        self.action_buttons = []
        self.robot_status_label = None; self.drag_status_label = None
        self.connect_button = None
        self.record_button = None; self.stop_record_button = None; self.record_status_label = None
        self.trajectory_combo = None; self.refresh_traj_button = None
        self.speed_slider = None; self.speed_label = None
        self.play_button = None; self.pause_button = None; self.resume_button = None
        self.stop_play_button = None; self.play_status_label = None

        # Action Map
        self.action_map = {
            "ConnecttoPatient": self._connect_patient,
            "RecordExercise": self._record_exercise,
            "PlayExercise": self._play_exercise
        }

        # Initialize UI Phases
        self._init_ui()
        self._connect_robot()
        self._apply_styles()
        # Note: _load_trajectory_names is called within _connect_robot now
        self._update_ui_state()


    def _connect_robot(self):
        """Attempts connection, checks methods, updates status, loads trajectories."""
        try:
            print(f"Attempting to connect to robot at {ROBOT_IP}...")
            self.robot = Robot.RPC(ROBOT_IP)
            print("Robot connection object created successfully.")
            if self.robot_status_label: self.robot_status_label.setText("Status: <b style='color: #2E7D32;'>Connected</b>")

            missing_methods = [m for m in REQUIRED_METHODS if not hasattr(self.robot, m)]
            if missing_methods:
                 warning_msg = f"Missing expected functions: {', '.join(missing_methods)}. Some features might fail."
                 print(f"WARNING: {warning_msg}")
                 QMessageBox.warning(self, "Robot Methods Missing", warning_msg)

        except Exception as e:
            self.robot = None
            print(f"FATAL: Failed to connect to robot: {e}")
            if self.robot_status_label: self.robot_status_label.setText("Status: <b style='color: #C62828;'>Disconnected</b>")
            if "Dummy Robot" not in str(e): QMessageBox.critical(self, "Robot Connection Failed", f"Could not connect to robot at {ROBOT_IP}.\nError: {e}\n\nCheck IP/network.")
        finally:
             self._load_trajectory_names() # Load names after connection attempt
             self._update_ui_state()


    def _init_ui(self):
        """Initializes the main layout and tab structure."""
        main_layout = QVBoxLayout(self)
        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)
        self.connect_tab = QWidget(); self.record_tab = QWidget(); self.play_tab = QWidget()
        self.tab_widget.addTab(self.connect_tab, "1. Connect")
        self.tab_widget.addTab(self.record_tab, "2. Record Exercise")
        self.tab_widget.addTab(self.play_tab, "3. Playback Exercise")
        self._create_connect_tab(); self._create_record_tab(); self._create_play_tab()
        self.setLayout(main_layout)


    def _create_connect_tab(self):
        """Creates UI elements for the Connect Tab."""
        layout = QVBoxLayout(self.connect_tab); layout.setAlignment(Qt.AlignmentFlag.AlignTop); layout.setSpacing(15)
        self.robot_status_label = QLabel("Status: Connecting...")
        self.drag_status_label = QLabel("Drag Teach: <b style='color: #C62828;'>OFF</b>")
        font = QFont(); font.setPointSize(11); self.robot_status_label.setFont(font); self.drag_status_label.setFont(font)
        layout.addWidget(self.robot_status_label); layout.addWidget(self.drag_status_label)
        self.connect_button = QPushButton("Connect to Patient / Enable Drag")
        self.connect_button.setObjectName("ConnecttoPatient"); self.connect_button.setMinimumHeight(50); self.connect_button.setProperty("active", False)
        self.connect_button.setToolTip("Establishes connection readiness & Enables/Disables Drag Teach Mode")
        self.connect_button.clicked.connect(lambda: self.on_button_click(self.connect_button))
        layout.addWidget(self.connect_button); self.action_buttons.append(self.connect_button)
        layout.addStretch()


    def _create_record_tab(self):
        """Creates UI elements for the Record Tab."""
        layout = QVBoxLayout(self.record_tab); layout.setAlignment(Qt.AlignmentFlag.AlignTop); layout.setSpacing(15)
        self.record_button = QPushButton("Record Exercise")
        self.record_button.setObjectName("RecordExercise"); self.record_button.setMinimumHeight(50); self.record_button.setProperty("active", False)
        self.record_button.setToolTip("Enables Drag Teach and starts recording trajectory")
        self.record_button.clicked.connect(lambda: self.on_button_click(self.record_button))
        layout.addWidget(self.record_button); self.action_buttons.append(self.record_button)
        self.stop_record_button = QPushButton("Stop Recording")
        self.stop_record_button.setObjectName("StopRecord"); self.stop_record_button.setMinimumHeight(50)
        self.stop_record_button.clicked.connect(self._stop_action)
        layout.addWidget(self.stop_record_button)
        self.record_status_label = QLabel("Recording Status: Idle")
        font = QFont(); font.setPointSize(11); self.record_status_label.setFont(font)
        layout.addWidget(self.record_status_label)
        layout.addStretch()


    def _create_play_tab(self):
        """Creates UI elements for the Playback Tab."""
        layout = QVBoxLayout(self.play_tab); layout.setAlignment(Qt.AlignmentFlag.AlignTop); layout.setSpacing(15)
        # Trajectory Selection Row
        traj_select_layout = QHBoxLayout()
        traj_label = QLabel("Select Exercise:")
        self.trajectory_combo = QComboBox()
        # --- DEBUG PRINT ADDED HERE ---
        print(f"DEBUG: Created self.trajectory_combo object: {self.trajectory_combo}")
        # -----------------------------
        self.trajectory_combo.setToolTip("Select a recorded exercise"); self.trajectory_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.refresh_traj_button = QPushButton("Refresh List"); self.refresh_traj_button.setToolTip("Reload exercise names from log"); self.refresh_traj_button.clicked.connect(self._load_trajectory_names)
        traj_select_layout.addWidget(traj_label); traj_select_layout.addWidget(self.trajectory_combo, 1); traj_select_layout.addWidget(self.refresh_traj_button)
        layout.addLayout(traj_select_layout)
        # Speed Control Row
        speed_layout = QHBoxLayout()
        speed_title_label = QLabel("Playback Speed:"); self.speed_slider = QSlider(Qt.Orientation.Horizontal); self.speed_slider.setRange(1, 150); self.speed_slider.setValue(100); self.speed_slider.setTickInterval(10); self.speed_slider.setTickPosition(QSlider.TickPosition.TicksBelow); self.speed_slider.setToolTip("Adjust playback speed (1% to 150%)")
        self.speed_label = QLabel(f"{self.speed_slider.value()}%"); self.speed_label.setMinimumWidth(40); self.speed_slider.valueChanged.connect(self._update_speed_label)
        speed_layout.addWidget(speed_title_label); speed_layout.addWidget(self.speed_slider); speed_layout.addWidget(self.speed_label)
        layout.addLayout(speed_layout)
        # Play Button
        self.play_button = QPushButton("Play Selected Exercise"); self.play_button.setObjectName("PlayExercise"); self.play_button.setMinimumHeight(50); self.play_button.setProperty("active", False)
        self.play_button.clicked.connect(lambda: self.on_button_click(self.play_button))
        layout.addWidget(self.play_button); self.action_buttons.append(self.play_button)
        # Playback Control Buttons
        control_layout = QHBoxLayout()
        self.pause_button = QPushButton("Pause"); self.pause_button.setObjectName("PausePlayback"); self.pause_button.setMinimumHeight(45)
        self.resume_button = QPushButton("Resume"); self.resume_button.setObjectName("ResumePlayback"); self.resume_button.setMinimumHeight(45)
        self.stop_play_button = QPushButton("Stop Playback"); self.stop_play_button.setObjectName("StopPlayback"); self.stop_play_button.setMinimumHeight(45)
        self.pause_button.clicked.connect(self._pause_action); self.resume_button.clicked.connect(self._resume_action); self.stop_play_button.clicked.connect(self._stop_action)
        control_layout.addWidget(self.pause_button); control_layout.addWidget(self.resume_button); control_layout.addWidget(self.stop_play_button)
        layout.addLayout(control_layout)
        # Status Label
        self.play_status_label = QLabel("Playback Status: Idle"); font = QFont(); font.setPointSize(11); self.play_status_label.setFont(font)
        layout.addWidget(self.play_status_label)
        layout.addStretch()


    @pyqtSlot()
    def _load_trajectory_names(self):
        """Reads trajectory names from the CSV log file and populates the ComboBox."""
        if not self.trajectory_combo: return
        print(f"Loading trajectories from '{TRAJECTORY_CSV_FILE}'...")
        current_selection = self.trajectory_combo.currentText(); self.trajectory_combo.clear()
        if not os.path.isfile(TRAJECTORY_CSV_FILE): print(f"Info: Log file not found."); self.trajectory_combo.addItem("<Log file not found>"); self.trajectory_combo.setEnabled(False); self._update_ui_state(); return
        trajectory_names = set(); updated_count = 0
        try:
            with open(TRAJECTORY_CSV_FILE, 'r', newline='', encoding='utf-8') as csvfile:
                reader = csv.reader(csvfile); header = next(reader, None); name_col_index = 1
                if header: 
                    hdr_low=[h.lower().strip() for h in header]; 
                    try: name_col_index=hdr_low.index('trajectoryname'); print(f" Using column {name_col_index} ('TrajectoryName').")
                    except ValueError: print(f" Warn: 'TrajectoryName' not in header, using col {name_col_index}.")
                    else: print(" Warn: No header, assuming name in col 2 (idx 1).")
                for i, row in enumerate(reader):
                    if len(row)>name_col_index: name=row[name_col_index].strip(); (trajectory_names.add(name) if name else None)
                    # else: print(f"Warn: Row {i+(1 if header else 0)+1} too short.") # Reduce verbosity
            updated_count = len(trajectory_names)
        except Exception as e: print(f"Error reading CSV: {e}"); self.trajectory_combo.addItem("<Error reading log>"); self.trajectory_combo.setEnabled(False); self._update_ui_state(); return
        if trajectory_names:
            sorted_names = sorted(list(trajectory_names)); self.trajectory_combo.addItems(sorted_names)
            if current_selection in sorted_names: self.trajectory_combo.setCurrentText(current_selection)
            self.trajectory_combo.setEnabled(True); print(f"Loaded {updated_count} unique names.")
        else: print("Info: No valid names found."); self.trajectory_combo.addItem("<No trajectories in log>"); self.trajectory_combo.setEnabled(False)
        self._update_ui_state() # Ensure UI state is correct after loading


    @pyqtSlot(int)
    def _update_speed_label(self, value):
        """Updates the label next to the speed slider."""
        if self.speed_label: self.speed_label.setText(f"{value}%")


    def _apply_styles(self):
        """Applies the CSS stylesheet to the application."""
        # (Stylesheet remains the same as previous version)
        bg_color="#F0F4F8"; btn_bg_color="#E1E8F0"; btn_text_color="#27496D"; btn_border_color="#B0C4DE"; btn_hover_bg="#CAD7E3"; btn_pressed_bg="#B0C4DE"; active_bg_color="#65A8D7"; active_text_color="#FFFFFF"; active_border_color="#5595C7"; active_hover_bg="#85BBE1"; disabled_bg_color="#E8E8E8"; disabled_text_color="#A0A0A0"; disabled_border_color="#D0D0D0"; font_family="Segoe UI, Arial, sans-serif"; font_size="10pt"; tab_selected_color="#FFFFFF"; tab_bg_color="#D4DDE6"; slider_groove_bg="#FFFFFF"; slider_handle_bg=active_bg_color; slider_handle_border=active_border_color;
        stylesheet=f"""QWidget{{background-color:{bg_color};font-family:{font_family};font-size:{font_size};color:#333333;}}QTabBar::tab{{background:{tab_bg_color};color:{btn_text_color};border:1px solid {btn_border_color};border-bottom:none;border-top-left-radius:4px;border-top-right-radius:4px;padding:8px 15px;margin-right:2px;font-weight:bold;}}QTabBar::tab:hover{{background:{btn_hover_bg};}}QTabBar::tab:selected{{background:{tab_selected_color};color:{btn_text_color};border-color:{btn_border_color};border-bottom:1px solid {tab_selected_color};}}QTabWidget::pane{{border:1px solid {btn_border_color};border-top:none;background-color:{tab_selected_color};}}QPushButton{{background-color:{btn_bg_color};color:{btn_text_color};border:1px solid {btn_border_color};border-radius:5px;padding:10px 15px;outline:none;min-width:90px;font-weight:bold;}}QPushButton:hover{{background-color:{btn_hover_bg};border:1px solid {btn_border_color};}}QPushButton:pressed{{background-color:{btn_pressed_bg};}}QPushButton:disabled{{background-color:{disabled_bg_color};color:{disabled_text_color};border:1px solid {disabled_border_color};}}QPushButton[active="true"]{{background-color:{active_bg_color};color:{active_text_color};border:1px solid {active_border_color};font-weight:bold;}}QPushButton[active="true"]:hover{{background-color:{active_hover_bg};border:1px solid {active_border_color};}}QLabel{{color:#333333;padding:5px;}}QComboBox{{border:1px solid {btn_border_color};border-radius:3px;padding:4px 8px;min-height:24px;background-color:#FFFFFF;color:{btn_text_color};}}QComboBox:disabled{{background-color:{disabled_bg_color};color:{disabled_text_color};}}QComboBox::drop-down{{border:none;}}QComboBox QAbstractItemView{{border:1px solid {btn_border_color};background-color:#FFFFFF;color:{btn_text_color};selection-background-color:{active_bg_color};selection-color:{active_text_color};}}QSlider::groove:horizontal{{border:1px solid #bbb;background:{slider_groove_bg};height:8px;border-radius:4px;}}QSlider::handle:horizontal{{background:{slider_handle_bg};border:1px solid {slider_handle_border};width:18px;margin:-5px 0;border-radius:9px;}}QSlider::add-page:horizontal{{background:#ddd;border-radius:4px;}}QSlider::sub-page:horizontal{{background:{slider_handle_bg};border-radius:4px;}}"""
        self.setStyleSheet(stylesheet)


    def _refresh_button_style(self, button):
        """Forces a re-evaluation of the button's stylesheet."""
        if button: 
            try: style=button.style(); style.unpolish(button); style.polish(button)
            except Exception as e: print(f"Warn: Style refresh failed for {button.objectName()}: {e}")


    @pyqtSlot(QPushButton)
    def on_button_click(self, clicked_button):
        """Handles clicks on main action buttons (Connect, Record, Play)."""
        # (Logic remains the same as previous version - manages visuals, DT, dispatch)
        if clicked_button not in self.action_buttons: return
        clicked_obj_name=clicked_button.objectName(); is_active=clicked_button.property("active") or False; activate=not is_active; is_dt_ctrl=clicked_obj_name in DRAG_TEACH_CONTROLLERS
        print(f"Click '{clicked_obj_name}'. Active:{is_active}. Target:{'Activate' if activate else 'Deactivate'}")
        if is_active: clicked_button.setProperty("active",False); self._refresh_button_style(clicked_button); (self._disable_drag_teach() if is_dt_ctrl else None) # Deactivate clicked
        target_btn=None
        if activate: # Activate Clicked / Deactivate Others
            for btn in self.action_buttons:
                if btn and btn is not clicked_button and btn.property("active"):
                    other_name=btn.objectName(); print(f"  Deactivating other '{other_name}'"); btn.setProperty("active",False); self._refresh_button_style(btn); (self._disable_drag_teach() if other_name in DRAG_TEACH_CONTROLLERS else None)
            target_btn=clicked_button # Mark for activation attempt
        action_to_dispatch=None
        if target_btn: # Attempt activation
            target_name=target_btn.objectName(); can_activate=True
            if target_name in DRAG_TEACH_CONTROLLERS: # Enable DT first if controller
                print(f"  Attempting DT enable for '{target_name}'..."); can_activate=self._enable_drag_teach()
                if not can_activate: print(f"  DT enable FAILED. Aborting activation.")
            if can_activate: # Proceed if DT ok or not needed
                print(f"  Activating visual '{target_name}'"); target_btn.setProperty("active",True); self._refresh_button_style(target_btn)
                if target_name in self.action_map: action_to_dispatch=self.action_map[target_name]
                else: print(f"Warn: Action not found for '{target_name}'")
        if action_to_dispatch: # Dispatch if activation succeeded
            btn_text=target_btn.text(); print(f"  Dispatching action for '{btn_text}'");
            try: action_to_dispatch()
            except Exception as e: print(f"ERROR during action dispatch for {btn_text}: {e}"); self._show_robot_error(f"Error executing action:\n{e}",None); (target_btn.setProperty("active",False) or self._refresh_button_style(target_btn) if target_btn else None); (self._disable_drag_teach() if target_btn and target_btn.objectName() in DRAG_TEACH_CONTROLLERS else None) # Reset on error
        else: print("  No action dispatched.")
        self._update_ui_state() # Update UI based on final state


    def _enable_drag_teach(self):
        """Sends command to enable robot drag teach. Updates label. Returns True/False."""
        # (Logic remains same as previous version)
        if not self.robot: self._show_robot_error("Cannot enable Drag Teach: Robot not connected.", None); (self.drag_status_label.setText("Drag Teach: <b style='color: #C62828;'>OFF</b>") if self.drag_status_label else None) ; return False
        success=False; label_updated=False
        try: print("  Sending: DragTeachSwitch(1)"); ret=self.robot.DragTeachSwitch(1); print(f"  DragTeach(1) Response: {ret}"); success=(ret==0)
        except AttributeError: print("ERROR: Missing 'DragTeachSwitch'"); self._show_robot_error("Function 'DragTeachSwitch' not found.", None); success=False
        except Exception as e: print(f"  DragTeach(1) Ex: {e}"); self._show_robot_error(f"Exception enabling Drag Teach: {e}", None); success=False
        if self.drag_status_label: self.drag_status_label.setText("Drag Teach: <b style='color: #2E7D32;'>ON</b>" if success else "Drag Teach: <b style='color: #C62828;'>OFF</b>"); label_updated=True
        print(f"  Drag Teach {'enabled' if success else 'FAILED enable'}.")
        if not success and self.robot and not label_updated: self._show_robot_error("Failed to enable Drag Teach.", 'Robot Error/Exception')
        return success


    def _disable_drag_teach(self):
        """Sends command to disable robot drag teach. Updates label. Returns True/False."""
        # (Logic remains same as previous version)
        if not self.robot: print("Info: Cannot disable Drag Teach - Not connected."); (self.drag_status_label.setText("Drag Teach: <b style='color: #C62828;'>OFF</b>") if self.drag_status_label else None); return False
        print("  Attempting disable Drag Teach..."); success=False
        try: print("  Sending: DragTeachSwitch(0)"); ret=self.robot.DragTeachSwitch(0); print(f"  DragTeach(0) Response: {ret}"); success=(ret==0)
        except AttributeError: print("ERROR: Missing 'DragTeachSwitch'"); success=False
        except Exception as e: print(f"  DragTeach(0) Ex: {e}"); success=False
        if self.drag_status_label: self.drag_status_label.setText("Drag Teach: <b style='color: #C62828;'>OFF</b>") # Always set OFF
        print(f"  Drag Teach disable {'OK' if success else 'FAILED'}.")
        return success


    def _show_robot_error(self, message, error_code):
        """Displays a warning message box for robot-related errors."""
        # (Logic remains same as previous version)
        print(f"ROBOT ERROR: {message} (Code: {error_code})"); detail=f"Code: {error_code}" if error_code is not None else "N/A"; (QMessageBox.warning(self,"Robot Error",f"{message}\n\n{detail}") if self.isVisible() else None)


    def _update_ui_state(self):
        """Central method to enable/disable UI elements based on current state."""
        # (Logic remains same as previous version)
        conn=self.robot is not None; setup_play=conn and not self._is_recording and not self._is_playing and not self._is_paused; valid_traj=False
        if self.trajectory_combo: cur_traj=self.trajectory_combo.currentText(); valid_traj=bool(cur_traj) and not cur_traj.startswith("<")
        start_play=setup_play and valid_traj
        (self.connect_button.setEnabled(conn and not self._is_recording and not self._is_playing) if self.connect_button else None)
        (self.record_button.setEnabled(conn and not self._is_playing and not self._is_recording) if self.record_button else None)
        (self.play_button.setEnabled(start_play) if self.play_button else None)
        (self.stop_record_button.setEnabled(conn and self._is_recording) if self.stop_record_button else None)
        (self.trajectory_combo.setEnabled(setup_play) if self.trajectory_combo else None); (self.refresh_traj_button.setEnabled(setup_play) if self.refresh_traj_button else None); (self.speed_slider.setEnabled(setup_play) if self.speed_slider else None)
        (self.pause_button.setEnabled(conn and self._is_playing and not self._is_paused) if self.pause_button else None)
        (self.resume_button.setEnabled(conn and self._is_playing and self._is_paused) if self.resume_button else None)
        (self.stop_play_button.setEnabled(conn and (self._is_playing or self._is_paused)) if self.stop_play_button else None)
        if self.drag_status_label: is_dt_ui=any(b.property("active") for b in self.action_buttons if b and b.objectName() in DRAG_TEACH_CONTROLLERS); lbl_on=self.drag_status_label.text().endswith("ON</b>"); (self.drag_status_label.setText("DT: <b style='color: #2E7D32;'>ON</b>") if is_dt_ui and not lbl_on else (self.drag_status_label.setText("DT: <b style='color: #C62828;'>OFF</b>") if not is_dt_ui and lbl_on else None))
        print(f"UI State: Conn={conn}, Rec={self._is_recording}, Play={self._is_playing}, Paused={self._is_paused}, PlaySetup={setup_play}, PlayStart={start_play}")


    @pyqtSlot()
    def _connect_patient(self):
        """Action logic for 'Connect to Patient' button activation."""
        # (Logic remains same as previous version)
        print("ACTION: Connect Patient");
        if not self.robot: self._show_robot_error("Robot not connected.", None); (self.connect_button.setProperty("active",False) or self._refresh_button_style(self.connect_button) if self.connect_button else None); return
        print("  (DT ON - Add other setup logic?)")


    @pyqtSlot()
    def _record_exercise(self):
        """Action logic for 'Record Exercise' button activation."""
        # (Logic remains same as previous version - includes syntax fix)
        print("ACTION: Record Exercise");
        if not self.robot: print("ERROR: Record action but robot is None."); (self.record_button.setProperty("active", False) or self._refresh_button_style(self.record_button) if self.record_button and self.record_button.property("active") else None); self._disable_drag_teach(); return
        if self._is_recording or self._is_playing: print(f"WARN: Record action while busy (R:{self._is_recording},P:{self._is_playing})"); (self.record_button.setProperty("active",False) or self._refresh_button_style(self.record_button) if self.record_button else None); self._disable_drag_teach(); return
        def_name="Ex_"+datetime.now().strftime("%Y%m%d_%H%M%S"); name,ok=QInputDialog.getText(self,"Record","Name:",QLineEdit.EchoMode.Normal,def_name)
        if not ok or not name or not name.strip(): print("Info: Record cancelled."); (self.record_button.setProperty("active",False) or self._refresh_button_style(self.record_button) if self.record_button else None); self._disable_drag_teach(); return
        name=name.strip(); log_ok=False
        try: empty=not os.path.isfile(TRAJECTORY_CSV_FILE) or os.path.getsize(TRAJECTORY_CSV_FILE)==0; f=open(TRAJECTORY_CSV_FILE,'a',newline='',encoding='utf-8'); w=csv.writer(f); (w.writerow(['Timestamp','TrajectoryName']) if empty else None); w.writerow([datetime.now().strftime('%F %T'),name]); f.close(); print(f"Logged '{name}'"); self._load_trajectory_names(); log_ok=True
        except IOError as e: self._show_robot_error(f"Log error: {e}", None);
        if not log_ok: (self.record_button.setProperty("active",False) or self._refresh_button_style(self.record_button) if self.record_button else None); self._disable_drag_teach(); return
        try:
            print(f"Config TPD '{name}'..."); retP=self.robot.SetTPDParam(name,RECORDING_PERIOD,di_choose=RECORDING_DI); print(f" Rsp:{retP}"); assert retP==0
            print(f"Start TPD '{name}'..."); retS=self.robot.SetTPDStart(name,RECORDING_PERIOD,do_choose=RECORDING_DO); print(f" Rsp:{retS}"); assert retS==0
            print(f"Recording '{name}' started."); self._is_recording=True; self.current_recording_name=name; (self.record_status_label.setText(f"Status: <b style='color:red;'>RECORDING</b> ({name})") if self.record_status_label else None)
        except AttributeError as e: missing="?"; ('SetTPDParam' in str(e) and missing=='SetTPDParam') or ('SetTPDStart' in str(e) and missing=='SetTPDStart'); self._show_robot_error(f"Func '{missing}' missing.", None); self._is_recording=False; self.current_recording_name=None; (self.record_status_label.setText("Err(NoFunc)") if self.record_status_label else None); (self.record_button.setProperty("active",False) or self._refresh_button_style(self.record_button) if self.record_button else None); self._disable_drag_teach()
        except Exception as e: self._show_robot_error(f"Record setup error: {e}", None); self._is_recording=False; self.current_recording_name=None; (self.record_status_label.setText("Err(Setup)") if self.record_status_label else None); (self.record_button.setProperty("active",False) or self._refresh_button_style(self.record_button) if self.record_button else None); self._disable_drag_teach()


    @pyqtSlot()
    def _play_exercise(self):
        """Action logic for 'Play Exercise' button activation."""
        # (Logic remains same as previous version - uses SetSpeed, MoveL, Timer)
        print("ACTION: Play Exercise");
        if not self.trajectory_combo or not self.speed_slider: print("ERR: Play UI missing"); return
        name=self.trajectory_combo.currentText(); speed=self.speed_slider.value()
        if not name or name.startswith("<"): self._show_robot_error("Select valid exercise.", None); (self.play_button.setProperty("active",False) or self._refresh_button_style(self.play_button) if self.play_button else None); return
        if not self.robot: self._show_robot_error("Robot not connected.", None); (self.play_button.setProperty("active",False) or self._refresh_button_style(self.play_button) if self.play_button else None); return
        if self._is_recording: self._show_robot_error("Cannot play while recording.", None); (self.play_button.setProperty("active",False) or self._refresh_button_style(self.play_button) if self.play_button else None); return
        if self._is_playing: print("Info: Already playing."); return
        print(f"UI ACTION: Play '{name}' @ {speed}% speed.")
        try:
            print(f" Load TPD '{name}'..."); retL=self.robot.LoadTPD(name); print(f" Rsp:{retL}"); assert retL==0
            print(f" GetStartPose '{name}'..."); retP,pos=self.robot.GetTPDStartPose(name); print(f" Rsp:{retP} Pose:{pos}"); assert retP==0 and pos
            print(f" SetSpeed {speed}..."); retSp=self.robot.SetSpeed(speed); print(f" Rsp:{retSp}"); assert retSp==0
            print(f" MoveL to Start {pos}..."); retM=self.robot.MoveL(pos,0,0); print(f" Rsp:{retM}");
            if retM!=0: self._show_robot_error(f"MoveL to start failed (Code:{retM}). Trying play anyway.",retM)
            else: print(" Waiting post-MoveL..."); time.sleep(3)
            print(f" Assumed playback started for '{name}'. Starting monitor.")
            self._is_playing=True; self._is_paused=False; self.current_playback_name=name; (self.play_status_label.setText(f"<b style='color:green;'>PLAYING</b>({name}@{speed}%)") if self.play_status_label else None)
            self.playback_monitor_timer.start()

        except AttributeError as e: missing="?"; ('LoadTPD' in str(e) and missing=='LoadTPD') or ('GetTPDStartPose' in str(e) and missing=='GetTPDStartPose') or ('SetSpeed' in str(e) and missing=='SetSpeed') or ('MoveL' in str(e) and missing=='MoveL'); self._show_robot_error(f"Func '{missing}' missing.", None); self._is_playing=False; self.current_playback_name=None; (self.play_status_label.setText("Err(NoFunc)") if self.play_status_label else None); (self.play_button.setProperty("active",False) or self._refresh_button_style(self.play_button) if self.play_button else None)
        except Exception as e: self._show_robot_error(f"Play setup error for '{name}': {e}", None); self._is_playing=False; self._is_paused=False; self.current_playback_name=None; (self.play_status_label.setText("Err(Setup)") if self.play_status_label else None); (self.play_button.setProperty("active",False) or self._refresh_button_style(self.play_button) if self.play_button else None)


    @pyqtSlot()
    def _check_playback_status(self):
        """Called periodically by QTimer to check if robot motion is done."""
        # (Logic remains same as previous version)
        if not self.robot or not self._is_playing or self._is_paused: self.playback_monitor_timer.stop(); return
        try:
            ret, motion_done = self.robot.GetRobotMotionDone()
            if ret == 0 and motion_done == 1:
                print(f"Playback completed for '{self.current_playback_name}'.")
                self.playback_monitor_timer.stop()
                self._is_playing = False; self._is_paused = False; prev_name = self.current_playback_name; self.current_playback_name = None
                if self.play_status_label: self.play_status_label.setText(f"Status: Completed ({prev_name})")
                if self.play_button and self.play_button.property("active"): self.play_button.setProperty("active", False); self._refresh_button_style(self.play_button)
                self._update_ui_state()
        except AttributeError: print("ERROR: Robot object missing 'GetRobotMotionDone'. Stopping monitor & playback."); self.playback_monitor_timer.stop(); self._stop_action()
        except Exception as e: print(f"Error checking playback status: {e}")


    @pyqtSlot()
    def _stop_action(self):
        """Handles Stop button clicks (Record or Playback)."""
        # (Logic remains same as previous version)
        print("ACTION: Stop");
        if self.playback_monitor_timer.isActive(): self.playback_monitor_timer.stop(); print(" Playback monitor timer stopped.")
        was_recording=self._is_recording
        if self.robot:
            try: print(" Send StopMotion"); err=self.robot.StopMotion(); print(f" Rsp:{err}")
            except Exception as e: print(f" StopMotion Ex:{e}")
            if self._is_recording: print(f" Stop TPD '{self.current_recording_name}'"); 
            try: err=self.robot.SetWebTPDStop(); print(f" Rsp:{err}")
            except Exception as e: print(f" SetWebTPDStop Ex:{e}")
        self._is_recording=False; self.current_recording_name=None; (self.record_status_label.setText("Rec: Idle") if self.record_status_label else None)
        self._is_playing=False; self._is_paused=False; self.current_playback_name=None; (self.play_status_label.setText("Play: Idle") if self.play_status_label else None)
        (self.record_button.setProperty("active",False) or self._refresh_button_style(self.record_button) if self.record_button and self.record_button.property("active") else None)
        (self.play_button.setProperty("active",False) or self._refresh_button_style(self.play_button) if self.play_button and self.play_button.property("active") else None)
        (self.connect_button.setProperty("active",False) or self._refresh_button_style(self.connect_button) if self.connect_button and self.connect_button.property("active") else None)
        print(" Disable Drag Teach"); self._disable_drag_teach()
        print("Stop actions done."); sender=self.sender(); (sender.setProperty("active",False) or self._refresh_button_style(sender) if isinstance(sender,QPushButton) and sender.property("active") else None)
        self._update_ui_state()


    @pyqtSlot()
    def _resume_action(self):
        """Action logic for the Resume button."""
        # (Logic remains same as previous version)
        print("ACTION: Resume");
        if not self.robot: self._show_robot_error("Robot not connected.", None); return
        if not self._is_playing or not self._is_paused: print("Info: Cannot Resume"); return
        print(" Send ResumeMotion"); err=-1
        try: err=self.robot.ResumeMotion(); print(f" Rsp:{err}")
        except Exception as e: self._show_robot_error(f"Resume Ex: {e}", None)
        if err==0:
            self._is_paused=False; speed=self.speed_slider.value() if self.speed_slider else 100
            (self.play_status_label.setText(f"<b style='color:green;'>PLAYING</b>({self.current_playback_name}@{speed}%)") if self.play_status_label else None)
            self.playback_monitor_timer.start(); print(" Playback monitor timer restarted.")
        else:
            if err!=-1: self._show_robot_error("Resume failed.", err)
        self._update_ui_state()


    @pyqtSlot()
    def _pause_action(self):
        """Action logic for the Pause button."""
        # (Logic remains same as previous version)
        print("ACTION: Pause");
        if not self.robot: self._show_robot_error("Robot not connected.", None); return
        if not self._is_playing or self._is_paused: print("Info: Cannot Pause"); return
        if self.playback_monitor_timer.isActive(): self.playback_monitor_timer.stop(); print(" Playback monitor timer paused.")
        print(" Send PauseMotion"); err=-1
        try: err=self.robot.PauseMotion(); print(f" Rsp:{err}")
        except Exception as e: self._show_robot_error(f"Pause Ex: {e}", None)
        if err==0:
            self._is_paused=True; speed=self.speed_slider.value() if self.speed_slider else 100
            (self.play_status_label.setText(f"<b style='color:orange;'>PAUSED</b>({self.current_playback_name}@{speed}%)") if self.play_status_label else None)
        else:
             if err!=-1: self._show_robot_error("Pause failed.", err)
        self._update_ui_state()


    def closeEvent(self, event):
        """Handles the window close event, ensuring cleanup."""
        # (Logic remains same as previous version)
        print("UI: Close event triggered.")
        if self.playback_monitor_timer.isActive(): self.playback_monitor_timer.stop(); print(" Playback monitor timer stopped on close.")
        needs_stop = self._is_recording or self._is_playing or self._is_paused
        dt_active = any(b.property("active") for b in self.action_buttons if b and b.objectName() in DRAG_TEACH_CONTROLLERS)
        if needs_stop: print(" Closing: Stopping active actions..."); self._stop_action(); QApplication.processEvents(); time.sleep(0.3)
        elif dt_active: print(" Closing: Disabling Drag Teach..."); self._disable_drag_teach(); QApplication.processEvents(); time.sleep(0.2)
        print(" Closing: Accepting close event.")
        super().closeEvent(event)


# --- Main Execution Block ---
if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setApplicationName("Robot Control Interface")
    try: app.setWindowIcon(QIcon.fromTheme("applications-engineering"))
    except Exception as e: print(f"Info: Could not set icon: {e}")
    window = RobotControlTabsApp()
    window.show()
    sys.exit(app.exec())