# -*- coding: utf-8 -*-
"""
PyQt6 UI for robot control using Tabs.
Record Exercise prompts for name, logs CSV, ENABLES DRAG TEACH, starts TPD.
Connect to Patient ALSO ENABLES/DISABLES DRAG TEACH independently.
UI state (button enables, status labels) updated based on actions.
Drag Teach enabled if Connect OR Record is active, disabled otherwise or on Stop.
"""

import sys
import time
import csv
from datetime import datetime
import os

# --- Robot Import ---
try:
    import Robot
    print("Successfully imported Robot library.")
except ImportError:
    print("FATAL ERROR: 'Robot' library not found. Exiting.")
    sys.exit(1)

from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QGridLayout, QMessageBox,
    QInputDialog, QLineEdit, QTabWidget, QVBoxLayout, QLabel, QSizePolicy, QHBoxLayout
)
from PyQt6.QtGui import QIcon, QFont
from PyQt6.QtCore import QSize, pyqtSlot, Qt

# --- Configuration ---
ROBOT_IP = '192.168.58.2'
TRAJECTORY_CSV_FILE = 'trajectory_log.csv'
RECORDING_PERIOD = 4
RECORDING_DI = 0
RECORDING_DO = 0

# Constants for button object names controlling Drag Teach
DRAG_TEACH_CONTROLLERS = {"ConnecttoPatient", "RecordExercise"}

class RobotControlTabsApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ultramotiv Rehab")
        self.setGeometry(300, 200, 600, 400)

        # State Flags
        self.robot = None
        self._is_recording = False
        self._is_playing = False
        self._is_paused = False
        # Removed self._drag_teach_on_by_record, logic based on active buttons now
        self.current_recording_name = None
        self.current_playback_name = None

        # UI Element References
        self.action_buttons = []
        self.connect_button = None
        self.record_button = None
        self.play_button = None
        self.stop_record_button = None
        self.stop_play_button = None
        self.pause_button = None
        self.resume_button = None
        self.robot_status_label = None
        self.drag_status_label = None
        self.record_status_label = None
        self.play_status_label = None

        # Action Map
        self.action_map = {
            "ConnecttoPatient": self._connect_patient,
            "RecordExercise": self._record_exercise,
            "PlayExercise": self._play_exercise
        }

        self._init_ui()
        self._connect_robot()
        self._apply_styles()
        self._update_ui_state()


    def _connect_robot(self):
        # (Same as before)
        try:
            print(f"Attempting to connect to robot at {ROBOT_IP}...")
            self.robot = Robot.RPC(ROBOT_IP)
            print("Robot connection object created successfully.")
            if self.robot_status_label:
                 self.robot_status_label.setText("Status: <b style='color: #2E7D32;'>Connected</b>")

        except Exception as e:
            self.robot = None
            print(f"FATAL: Failed to connect to robot: {e}")
            if self.robot_status_label:
                 self.robot_status_label.setText("Status: <b style='color: #C62828;'>Disconnected</b>")
            QMessageBox.critical(self, "Robot Connection Failed",
                                 f"Could not connect to robot at {ROBOT_IP}.\nError: {e}\n\nAll controls disabled.")
        finally:
             self._update_ui_state()


    def _init_ui(self):
        # (Same as before)
        main_layout = QVBoxLayout(self)
        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)
        self.connect_tab = QWidget(); self.record_tab = QWidget(); self.play_tab = QWidget()
        self.tab_widget.addTab(self.connect_tab, "1. Connect")
        self.tab_widget.addTab(self.record_tab, "2. Record Exercise")
        self.tab_widget.addTab(self.play_tab, "3. Playback Exercise")
        self._create_connect_tab(); self._create_record_tab(); self._create_play_tab()
        self.setLayout(main_layout)


    def _create_connect_tab(self):
        # (Connect button now also controls Drag Teach)
        layout = QVBoxLayout(self.connect_tab); layout.setAlignment(Qt.AlignmentFlag.AlignTop); layout.setSpacing(15)
        self.robot_status_label = QLabel("Status: Unknown")
        self.drag_status_label = QLabel("Drag Teach: <b style='color: #C62828;'>OFF</b>")
        font = QFont(); font.setPointSize(11); self.robot_status_label.setFont(font); self.drag_status_label.setFont(font)
        layout.addWidget(self.robot_status_label); layout.addWidget(self.drag_status_label)
        self.connect_button = QPushButton("Connect to Patient / Enable Drag") # Updated text
        self.connect_button.setObjectName("ConnecttoPatient")
        self.connect_button.setMinimumHeight(50); self.connect_button.setProperty("active", False)
        self.connect_button.setToolTip("Enables Robot Interaction & Drag Teach Mode") # Tooltip updated
        self.connect_button.clicked.connect(lambda: self.on_button_click(self.connect_button))
        layout.addWidget(self.connect_button); self.action_buttons.append(self.connect_button)
        layout.addStretch()


    def _create_record_tab(self):
        # (Record button also controls Drag Teach)
        layout = QVBoxLayout(self.record_tab); layout.setAlignment(Qt.AlignmentFlag.AlignTop); layout.setSpacing(15)
        self.record_button = QPushButton("Record Exercise")
        self.record_button.setObjectName("RecordExercise")
        self.record_button.setMinimumHeight(50); self.record_button.setProperty("active", False)
        self.record_button.setToolTip("Enables Drag Teach and starts recording trajectory")
        self.record_button.clicked.connect(lambda: self.on_button_click(self.record_button))
        layout.addWidget(self.record_button); self.action_buttons.append(self.record_button)
        self.stop_record_button = QPushButton("Stop Recording")
        self.stop_record_button.setObjectName("StopRecord"); self.stop_record_button.setMinimumHeight(50)
        self.stop_record_button.clicked.connect(self._stop_action) # Direct connection
        layout.addWidget(self.stop_record_button)
        self.record_status_label = QLabel("Recording Status: Idle")
        font = QFont(); font.setPointSize(11); self.record_status_label.setFont(font)
        layout.addWidget(self.record_status_label)
        layout.addStretch()


    def _create_play_tab(self):
        # (Play button does NOT control Drag Teach)
        layout = QVBoxLayout(self.play_tab); layout.setAlignment(Qt.AlignmentFlag.AlignTop); layout.setSpacing(15)
        self.play_button = QPushButton("Play Exercise")
        self.play_button.setObjectName("PlayExercise")
        self.play_button.setMinimumHeight(50); self.play_button.setProperty("active", False)
        self.play_button.clicked.connect(lambda: self.on_button_click(self.play_button))
        layout.addWidget(self.play_button); self.action_buttons.append(self.play_button)
        control_layout = QHBoxLayout()
        self.pause_button = QPushButton("Pause"); self.pause_button.setObjectName("PausePlayback"); self.pause_button.setMinimumHeight(45)
        self.resume_button = QPushButton("Resume"); self.resume_button.setObjectName("ResumePlayback"); self.resume_button.setMinimumHeight(45)
        self.stop_play_button = QPushButton("Stop Playback"); self.stop_play_button.setObjectName("StopPlayback"); self.stop_play_button.setMinimumHeight(45)
        self.pause_button.clicked.connect(self._pause_action)
        self.resume_button.clicked.connect(self._resume_action)
        self.stop_play_button.clicked.connect(self._stop_action)
        control_layout.addWidget(self.pause_button); control_layout.addWidget(self.resume_button); control_layout.addWidget(self.stop_play_button)
        layout.addLayout(control_layout)
        self.play_status_label = QLabel("Playback Status: Idle")
        font = QFont(); font.setPointSize(11); self.play_status_label.setFont(font)
        layout.addWidget(self.play_status_label)
        layout.addStretch()


    def _apply_styles(self):
        # (Same as before)
        bg_color="#F0F4F8"; btn_bg_color="#E1E8F0"; btn_text_color="#27496D"; btn_border_color="#B0C4DE"; btn_hover_bg="#CAD7E3"; btn_pressed_bg="#B0C4DE"; active_bg_color="#65A8D7"; active_text_color="#FFFFFF"; active_border_color="#5595C7"; active_hover_bg="#85BBE1"; disabled_bg_color="#E8E8E8"; disabled_text_color="#A0A0A0"; disabled_border_color="#D0D0D0"; font_family="Segoe UI, Arial, sans-serif"; font_size="10pt"; tab_selected_color = "#FFFFFF"; tab_bg_color="#D4DDE6"
        stylesheet=f"""QWidget {{ background-color: {bg_color}; font-family: {font_family}; font-size: {font_size}; color: #333333; }} QTabBar::tab {{ background: {tab_bg_color}; color: {btn_text_color}; border: 1px solid {btn_border_color}; border-bottom: none; border-top-left-radius: 4px; border-top-right-radius: 4px; padding: 8px 15px; margin-right: 2px; font-weight: bold; }} QTabBar::tab:hover {{ background: {btn_hover_bg}; }} QTabBar::tab:selected {{ background: {tab_selected_color}; color: {btn_text_color}; border-color: {btn_border_color}; border-bottom: 1px solid {tab_selected_color}; }} QTabWidget::pane {{ border: 1px solid {btn_border_color}; border-top: none; background-color: {tab_selected_color}; }} QPushButton {{ background-color: {btn_bg_color}; color: {btn_text_color}; border: 1px solid {btn_border_color}; border-radius: 5px; padding: 10px 15px; outline: none; min-width: 90px; font-weight: bold; }} QPushButton:hover {{ background-color: {btn_hover_bg}; border: 1px solid {btn_border_color}; }} QPushButton:pressed {{ background-color: {btn_pressed_bg}; }} QPushButton:disabled {{ background-color: {disabled_bg_color}; color: {disabled_text_color}; border: 1px solid {disabled_border_color}; }} QPushButton[active="true"] {{ background-color: {active_bg_color}; color: {active_text_color}; border: 1px solid {active_border_color}; font-weight: bold; }} QPushButton[active="true"]:hover {{ background-color: {active_hover_bg}; border: 1px solid {active_border_color}; }} QLabel {{ color: #333333; padding: 5px; }} QLabel#internalTitleLabel {{ font-size: 14pt; font-weight: bold; color: #1C3A5D; padding-top: 5px; padding-bottom: 15px; border: none; background-color: transparent; }}"""
        self.setStyleSheet(stylesheet)


    def _refresh_button_style(self, button):
        # (Same as before)
        if button: style = button.style(); style.unpolish(button); style.polish(button)


    # --- MODIFIED Slot: Handles Visuals, Drag Teach (Connect OR Record), AND Dispatches Action ---
    @pyqtSlot(QPushButton)
    def on_button_click(self, clicked_button):
        """Handles visual state toggle for action buttons.
           Connect/Record buttons also toggle Drag Teach. Dispatches action if activation succeeds."""
        if clicked_button not in self.action_buttons:
            print(f"Debug: on_button_click called for non-action button: {clicked_button.text()}. Ignoring.")
            return

        clicked_button_object_name = clicked_button.objectName()
        is_already_active = clicked_button.property("active") or False
        intended_new_state_for_clicked = not is_already_active
        is_drag_teach_controller = clicked_button_object_name in DRAG_TEACH_CONTROLLERS

        print(f"Click on '{clicked_button_object_name}'. Was active: {is_already_active}. Target state: {'Activate' if intended_new_state_for_clicked else 'Deactivate'}")

        # --- Step 1: Handle Deactivation / Deactivate Others ---
        button_to_finally_activate = None

        # Deactivate the clicked button first if it was active
        if is_already_active:
            print(f"  Deactivating visual for clicked '{clicked_button_object_name}'")
            clicked_button.setProperty("active", False)
            self._refresh_button_style(clicked_button)
            # If a drag teach controller was deactivated visually, disable drag teach
            if is_drag_teach_controller:
                self._disable_drag_teach()

        # If the intent was to activate the clicked button
        if intended_new_state_for_clicked:
            # First, deactivate all OTHER action buttons
            for button in self.action_buttons:
                if button is not clicked_button and button.property("active"):
                    other_obj_name = button.objectName()
                    print(f"  Deactivating visual for other '{other_obj_name}'")
                    button.setProperty("active", False)
                    self._refresh_button_style(button)
                    # If the *other* deactivated button was a drag teach controller, disable drag teach
                    if other_obj_name in DRAG_TEACH_CONTROLLERS:
                         self._disable_drag_teach()

            # Mark the clicked button to be activated (visually and functionally)
            button_to_finally_activate = clicked_button
        else:
            # If the intent was just to deactivate, no button will be finally activated
             button_to_finally_activate = None


        # --- Step 2: Activate Target Button & Handle Drag Teach (if applicable) ---
        action_to_dispatch = None
        if button_to_finally_activate:
            target_obj_name = button_to_finally_activate.objectName()
            drag_teach_needed_and_failed = False

            # Special handling for Drag Teach controllers on activation
            if target_obj_name in DRAG_TEACH_CONTROLLERS:
                print(f"  Attempting to enable Drag Teach for '{target_obj_name}' activation...")
                drag_teach_success = self._enable_drag_teach()
                if not drag_teach_success:
                    # Drag Teach failed, prevent button activation and action dispatch
                    print(f"  Drag Teach enable FAILED. Aborting activation of '{target_obj_name}'.")
                    drag_teach_needed_and_failed = True
                    button_to_finally_activate = None # Don't proceed with activation
                    # Ensure status label shows OFF (should be handled by _enable_drag_teach on failure)


            # Activate visually *if* it's still the target AND drag teach didn't fail
            if button_to_finally_activate: # Check again as it might be None now
                 print(f"  Activating visual for '{target_obj_name}'")
                 button_to_finally_activate.setProperty("active", True)
                 self._refresh_button_style(button_to_finally_activate)
                 # Map the action to be dispatched
                 if target_obj_name in self.action_map:
                     action_to_dispatch = self.action_map[target_obj_name]
                 else:
                     print(f"Warning: Action not found for '{target_obj_name}' in action_map")


        # --- Step 3: Dispatch Action ---
        if action_to_dispatch:
            active_button_text = button_to_finally_activate.text() # Get text for logging
            print(f"  Dispatching action for newly activated button: {active_button_text}")
            action_to_dispatch() # Call the corresponding action slot
        else:
            print("  No action dispatched.")


        # --- Step 4: Update UI State ---
        # Update overall UI state AFTER potential state changes from action
        self._update_ui_state()


    # --- Robot Interaction Helper Methods ---
    def _enable_drag_teach(self):
        # (Same as before - returns True/False, updates label)
        if not self.robot:
            self._show_robot_error("Cannot enable Drag Teach: Robot not connected.", None)
            return False
        success = False
        try:
            print("  Sending: DragTeachSwitch(1)")
            ret = self.robot.DragTeachSwitch(1)
            print(f"  DragTeach(1) Response: {ret}")
            success = (ret == 0)
        except Exception as e:
            print(f"  DragTeach(1) Exception: {e}")
            self._show_robot_error(f"Exception enabling Drag Teach: {e}", None)
            success = False
        if success:
            self.drag_status_label.setText("Drag Teach: <b style='color: #2E7D32;'>ON</b>")
            print("  Drag Teach successfully enabled.")
        else:
            self.drag_status_label.setText("Drag Teach: <b style='color: #C62828;'>OFF</b>")
            # Don't show redundant error if connection was the issue
            if self.robot: self._show_robot_error("Failed to enable Drag Teach.", 'Robot Error or Exception')
            print("  Failed to enable Drag Teach.")
        return success

    def _disable_drag_teach(self):
        # (Same as before - returns True/False, updates label to OFF)
        if not self.robot:
             print("Info: Cannot disable Drag Teach - Robot not connected.")
             self.drag_status_label.setText("Drag Teach: <b style='color: #C62828;'>OFF</b>")
             return False

        # Check if any *other* drag teach controller is still active
        # This prevents disabling if Connect is active and Record is deactivated (or vice versa)
        any_other_dt_controller_active = False
        for button in self.action_buttons:
            if button.objectName() in DRAG_TEACH_CONTROLLERS and button.property("active"):
                # This logic happens *during* the click handling, so the button *being* deactivated
                # might still appear active here. We need context or check the intended state.
                # Let's simplify: Always attempt to disable if requested by a button deactivation or stop.
                # The robot controller should handle repeated disable commands gracefully.
                pass # Keep simple for now: always attempt disable if requested.

        print("  Attempting to disable Drag Teach...")
        success = False
        try:
            print("  Sending: DragTeachSwitch(0)")
            ret = self.robot.DragTeachSwitch(0)
            print(f"  DragTeach(0) Response: {ret}")
            success = (ret == 0)
        except Exception as e:
            print(f"  DragTeach(0) Exception: {e}")
            success = False

        # Always update Label to OFF after attempting disable
        self.drag_status_label.setText("Drag Teach: <b style='color: #C62828;'>OFF</b>")
        if success: print("  Drag Teach disabled successfully.")
        else: print("  Failed to disable Drag Teach (command error or exception).")
        return success

    def _show_robot_error(self, message, error_code):
        # (Same as before)
        print(f"ROBOT ERROR: {message} (Code: {error_code})"); detail = f"Error code: {error_code}" if error_code is not None else "No error code available."; QMessageBox.warning(self, "Robot Interaction Error", f"{message}\n\n{detail}")


    def _update_ui_state(self):
        # (Logic largely remains similar, relies on _is_recording/_is_playing flags)
        connected = self.robot is not None
        # Check if any drag teach controller button is currently active
        is_dt_active = any(
            btn.property("active") for btn in self.action_buttons
            if btn.objectName() in DRAG_TEACH_CONTROLLERS
        )

        # Enable main action buttons based on state
        # Connect: Enabled if connected AND no other action (Record/Play) is running.
        if self.connect_button: self.connect_button.setEnabled(connected and not self._is_recording and not self._is_playing)
        # Record: Enabled if connected AND not playing/recording.
        if self.record_button: self.record_button.setEnabled(connected and not self._is_playing and not self._is_recording)
        # Play: Enabled if connected AND not recording.
        if self.play_button: self.play_button.setEnabled(connected and not self._is_recording)

        # Record tab controls
        if self.stop_record_button: self.stop_record_button.setEnabled(connected and self._is_recording)

        # Playback tab controls
        if self.pause_button: self.pause_button.setEnabled(connected and self._is_playing and not self._is_paused)
        if self.resume_button: self.resume_button.setEnabled(connected and self._is_playing and self._is_paused)
        if self.stop_play_button: self.stop_play_button.setEnabled(connected and (self._is_playing or self._is_paused))

        # Update drag teach label based on combined state (optional refinement)
        # The label is primarily updated by _enable/_disable helpers, but this could be a failsafe
        # if is_dt_active and self.drag_status_label.text().endswith("OFF</b>"):
        #     self.drag_status_label.setText("Drag Teach: <b style='color: #2E7D32;'>ON</b>") # Correct label if needed
        # elif not is_dt_active and self.drag_status_label.text().endswith("ON</b>"):
        #      self.drag_status_label.setText("Drag Teach: <b style='color: #C62828;'>OFF</b>")

        print(f"UI State Updated: Connected={connected}, Recording={self._is_recording}, Playing={self._is_playing}, Paused={self._is_paused}, DT_Active(UI)={is_dt_active}")


    # --- Dedicated Slots for Button Actions (Called by Dispatcher) ---

    @pyqtSlot()
    def _connect_patient(self):
        """Handles 'Connect to Patient' action. Assumes Drag Teach enabled by caller."""
        print("ACTION: 'Connect to Patient' action executed.")
        if not self.robot: self._show_robot_error("Robot not available.", None); return
        # Drag Teach was handled by on_button_click
        print("  (Drag Teach ON - Connect action can perform other setup if needed)")
        # Example: self.robot.SetSomeMode(...)
        # No state changes needed here unless the action itself fails
        self._update_ui_state()


    @pyqtSlot()
    def _record_exercise(self):
        """Handles Record Exercise action. Assumes Drag Teach enabled by caller.
           Prompts name, logs, starts TPD. Disables DT on failure/cancel."""
        print("ACTION: 'Record Exercise' action execution started.")
        # --- Precondition Checks (Safety) ---
        if not self.robot:
             print("ERROR: _record_exercise called but robot is None.")
             if self.record_button.property("active"): self.record_button.setProperty("active", False); self._refresh_button_style(self.record_button)
             self._disable_drag_teach() # Ensure DT is off
             self._update_ui_state(); return
        if self._is_recording or self._is_playing:
             print(f"WARN: Record action called while recording={self._is_recording} or playing={self._is_playing}")
             if self.record_button.property("active"): self.record_button.setProperty("active", False); self._refresh_button_style(self.record_button)
             self._disable_drag_teach() # Ensure DT is off
             self._update_ui_state(); return

        # --- Drag Teach Assumed ON ---
        # (Removed connection check)

        # --- Prompt for Trajectory Name & Log to CSV ---
        traj_name, ok = QInputDialog.getText(self, "Trajectory Name", "Enter name for recording:", QLineEdit.EchoMode.Normal, "Exercise_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
        if not ok or not traj_name or not traj_name.strip():
            print("UI Info: Recording cancelled by user or empty name.")
            if self.record_button.property("active"): self.record_button.setProperty("active", False); self._refresh_button_style(self.record_button)
            self._disable_drag_teach() # Crucial: Turn off drag teach
            self._update_ui_state(); return
        traj_name = traj_name.strip()

        # --- CSV Logging ---
        try:
             file_exists = os.path.isfile(TRAJECTORY_CSV_FILE); is_empty = not file_exists or os.path.getsize(TRAJECTORY_CSV_FILE) == 0
             with open(TRAJECTORY_CSV_FILE, 'a', newline='', encoding='utf-8') as f: writer = csv.writer(f); (writer.writerow(['Timestamp', 'TrajectoryName']) if is_empty else None); writer.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), traj_name])
             print(f"UI Info: Trajectory '{traj_name}' logged.")
        except IOError as e:
             self._show_robot_error(f"Failed to write to CSV log '{TRAJECTORY_CSV_FILE}':\n{e}", None)
             if self.record_button.property("active"): self.record_button.setProperty("active", False); self._refresh_button_style(self.record_button)
             self._disable_drag_teach() # Crucial: Turn off drag teach
             self._update_ui_state(); return

        # --- Send Robot Commands ---
        try:
            print(f"UI ACTION: Configuring TPD for '{traj_name}'...")
            ret_param = self.robot.SetTPDParam(traj_name, RECORDING_PERIOD, di_choose=RECORDING_DI); print(f"  SetTPDParam Response: {ret_param}")
            if ret_param != 0: raise Exception(f"SetTPDParam failed (Code: {ret_param})")
            print(f"UI ACTION: Starting TPD for '{traj_name}'...")
            ret_start = self.robot.SetTPDStart(traj_name, RECORDING_PERIOD, do_choose=RECORDING_DO); print(f"  SetTPDStart Response: {ret_start}")
            if ret_start != 0: raise Exception(f"SetTPDStart failed (Code: {ret_start})")

            # --- Recording Started Successfully ---
            print(f"UI Info: Recording started for '{traj_name}'.")
            self._is_recording = True
            self.current_recording_name = traj_name
            self.record_status_label.setText(f"Status: <b style='color: #C62828;'>RECORDING</b> ({traj_name})")

        except Exception as e:
            self._show_robot_error(f"Exception during recording setup for '{traj_name}': {e}", None)
            self._is_recording = False
            self.current_recording_name = None
            self.record_status_label.setText("Status: <b style='color: #C62828;'>Error starting record</b>")
            if self.record_button.property("active"): self.record_button.setProperty("active", False); self._refresh_button_style(self.record_button)
            self._disable_drag_teach() # Crucial: Turn off drag teach

        self._update_ui_state()


    @pyqtSlot()
    def _play_exercise(self):
        # (Same as before - No Drag Teach interaction here)
        print("ACTION: 'Play Exercise' action execution started.")
        if self._is_recording:
             self._show_robot_error("Cannot play: Recording is active. Stop recording first.", None)
             if self.play_button.property("active"): self.play_button.setProperty("active", False); self._refresh_button_style(self.play_button)
             self._update_ui_state(); return
        if self._is_playing: print("Info: Play button clicked but already playing."); return
        if not self.robot:
             self._show_robot_error("Cannot play: Robot not connected.", None)
             if self.play_button.property("active"): self.play_button.setProperty("active", False); self._refresh_button_style(self.play_button)
             self._update_ui_state(); return
        trajectory_to_play = self.current_recording_name # TODO: Add selection logic
        if not trajectory_to_play:
             self._show_robot_error("No trajectory selected or recorded in this session.", None)
             if self.play_button.property("active"): self.play_button.setProperty("active", False); self._refresh_button_style(self.play_button)
             self._update_ui_state(); return
        print(f"UI ACTION: Attempting to play trajectory '{trajectory_to_play}'...")
        # --- Add robot playback command ---
        print("PLACEHOLDER: Add actual robot playback command here and error handling.")
        # --- Placeholder Success ---
        self._is_playing = True; self._is_paused = False; self.current_playback_name = trajectory_to_play
        self.play_status_label.setText(f"Status: <b style='color: #2E7D32;'>PLAYING</b> ({trajectory_to_play})")
        # --- End Placeholder ---
        self._update_ui_state()


    @pyqtSlot()
    def _stop_action(self):
        """Handles Stop button clicks: Stops Motion, TPD Recording, Playback.
           Also disables Drag Teach."""
        print("ACTION: 'Stop' button clicked.")
        was_recording = self._is_recording # Check state before changing it
        was_playing = self._is_playing or self._is_paused

        if self.robot:
            # 1. Stop Motion
            try: print("  Sending StopMotion..."); err_stop = self.robot.StopMotion(); print(f"  StopMotion response: {err_stop}")
            except Exception as e: print(f"  Exception during StopMotion: {e}") # Log only

            # 2. Stop TPD Recording (if active)
            if self._is_recording:
                print(f"  Stopping TPD recording for '{self.current_recording_name}'...")
                try: err_tpd = self.robot.SetWebTPDStop(); print(f"  SetWebTPDStop response: {err_tpd}")
                except Exception as e: print(f"  Exception stopping TPD: {e}") # Log only
            # Reset recording state regardless of TPD stop success
            self._is_recording = False; self.current_recording_name = None
            self.record_status_label.setText("Recording Status: Idle")
            if self.record_button and self.record_button.property("active"): self.record_button.setProperty("active", False); self._refresh_button_style(self.record_button)

            # 3. Stop Playback (if active/paused)
            if self._is_playing or self._is_paused:
                 print("  Stopping playback (assuming StopMotion handles it)...")
                 # Add specific StopPlayback command if needed
            # Reset playback state
            self._is_playing = False; self._is_paused = False; self.current_playback_name = None
            self.play_status_label.setText("Playback Status: Idle")
            if self.play_button and self.play_button.property("active"): self.play_button.setProperty("active", False); self._refresh_button_style(self.play_button)

            # 4. Disable Drag Teach (since Stop overrides Connect/Record active states)
            print("  Disabling Drag Teach due to Stop action.")
            self._disable_drag_teach()
            # Ensure Connect button visual state is off too if Stop was pressed
            if self.connect_button and self.connect_button.property("active"):
                 self.connect_button.setProperty("active", False); self._refresh_button_style(self.connect_button)

        else: # Robot not connected
            print("WARN: Stop clicked but robot not connected. Resetting internal state.")
            self._is_recording = False; self._is_playing = False; self._is_paused = False
            self.record_status_label.setText("Recording Status: Idle (Not Connected)")
            self.play_status_label.setText("Playback Status: Idle (Not Connected)")
            self.drag_status_label.setText("Drag Teach: <b style='color: #C62828;'>OFF</b>")

        print("UI Info: Stop actions completed.")
        sender_button = self.sender()
        if isinstance(sender_button, QPushButton) and sender_button.property("active"): sender_button.setProperty("active", False); self._refresh_button_style(sender_button)
        self._update_ui_state()


    @pyqtSlot()
    def _resume_action(self):
        # (Same as before)
        print("ACTION: 'Resume' button clicked.")
        if not self._is_playing or not self._is_paused: print("Info: Cannot Resume - Not playing or not paused."); return
        if not self.robot: self._show_robot_error("Cannot Resume: Robot not connected.", None); return
        print("UI ACTION: Sending ResumeMotion command...")
        try: err = self.robot.ResumeMotion(); print(f"  ResumeMotion response: {err}")
        except Exception as e: self._show_robot_error(f"Exception during ResumeMotion: {e}", None); err = -1 # Assume error
        if err == 0: self._is_paused = False; self.play_status_label.setText(f"Status: <b style='color: #2E7D32;'>PLAYING</b> ({self.current_playback_name})")
        else: self._show_robot_error("ResumeMotion command failed.", err)
        self._update_ui_state()


    @pyqtSlot()
    def _pause_action(self):
        # (Same as before)
        print("ACTION: 'Pause' button clicked.")
        if not self._is_playing or self._is_paused: print("Info: Cannot Pause - Not playing or already paused."); return
        if not self.robot: self._show_robot_error("Cannot Pause: Robot not connected.", None); return
        print("UI ACTION: Sending PauseMotion command...")
        try: err = self.robot.PauseMotion(); print(f"  PauseMotion response: {err}")
        except Exception as e: self._show_robot_error(f"Exception during PauseMotion: {e}", None); err = -1 # Assume error
        if err == 0: self._is_paused = True; self.play_status_label.setText(f"Status: <b style='color: #E57373;'>PAUSED</b> ({self.current_playback_name})")
        else: self._show_robot_error("PauseMotion command failed.", err)
        self._update_ui_state()


    def closeEvent(self, event):
        # (Same as before - uses _stop_action for cleanup)
        print("UI: Close event triggered.")
        # Check if any action needs stopping
        needs_stop = self._is_recording or self._is_playing or self._is_paused
        # Check if any DT controller is active
        dt_needs_disable = any(
            btn.property("active") for btn in self.action_buttons
            if btn.objectName() in DRAG_TEACH_CONTROLLERS
        )

        if needs_stop:
            print("Window closing: Stopping active motion/recording/playback...")
            self._stop_action() # Use the stop action for consistent cleanup
            time.sleep(0.3) # Brief delay for commands

        # Ensure Drag Teach is disabled if necessary (Stop should handle, but be sure)
        if dt_needs_disable and not self.drag_status_label.text().endswith("OFF</b>"):
             print("Window closing: Ensuring Drag Teach is disabled...")
             self._disable_drag_teach()
             time.sleep(0.2)

        print("Window closing: Accepting close event.")
        super().closeEvent(event)

# --- Main Execution Block ---
if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setApplicationName("Robot Control Interface - Tabs")
    window = RobotControlTabsApp()
    window.show()
    sys.exit(app.exec())