import Robot
import time
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.cm as cm
from matplotlib.widgets import Slider, Button

# === Connect to Robot ===
print("Connecting to robot...")
robot = Robot.RPC('192.168.58.2')

# === FT Sensor Setup ===
print("Initializing FT sensor...")
config = robot.FT_GetConfig()
print("Sensor config:", config)
time.sleep(1)

robot.FT_Activate(0)
time.sleep(1)
robot.FT_Activate(1)
time.sleep(1)

robot.SetLoadCoord(0.0, 0.0, 0.0)
robot.FT_SetZero(0)
time.sleep(1)

# === Get Initial Pose ===
ret = robot.GetActualTCPPose()
pose = ret[1]  # [X, Y, Z, RX, RY, RZ]
initial_orientation = pose[3:]  # Save initial orientation
tool = 0
user = 0

# === Initial Parameters ===
force_to_mm = 1
torque_to_deg = 1
min_force_threshold = 0.3
max_move_mm = 10
max_rot_deg = 2
alpha = 0.6

# === 3D Plot Setup ===
plt.ion()
fig = plt.figure(figsize=(12, 10))
ax = fig.add_subplot(111, projection='3d')
plt.subplots_adjust(left=0.25, bottom=0.5)
cmap = cm.get_cmap('coolwarm')

# === Slider Axes ===
slider_axs = {
    "force_to_mm": plt.axes([0.25, 0.43, 0.65, 0.03]),
    "torque_to_deg": plt.axes([0.25, 0.39, 0.65, 0.03]),
    "max_move_mm": plt.axes([0.25, 0.35, 0.65, 0.03]),
    "max_rot_deg": plt.axes([0.25, 0.31, 0.65, 0.03]),
    "min_force_threshold": plt.axes([0.25, 0.27, 0.65, 0.03]),
    "alpha": plt.axes([0.25, 0.23, 0.65, 0.03]),
}

sliders = {
    "force_to_mm": Slider(slider_axs["force_to_mm"], 'Force → mm', 0.1, 10.0, valinit=force_to_mm),
    "torque_to_deg": Slider(slider_axs["torque_to_deg"], 'Torque → °', 0.1, 10.0, valinit=torque_to_deg),
    "max_move_mm": Slider(slider_axs["max_move_mm"], 'Max Move (mm)', 1, 50, valinit=max_move_mm),
    "max_rot_deg": Slider(slider_axs["max_rot_deg"], 'Max Rot (°)', 0.1, 10.0, valinit=max_rot_deg),
    "min_force_threshold": Slider(slider_axs["min_force_threshold"], 'Min ΔF (N)', 0.1, 5.0, valinit=min_force_threshold),
    "alpha": Slider(slider_axs["alpha"], 'LPF Alpha', 0.0, 0.99, valinit=alpha),
}

# === Button Axes ===
button_axs = {
    "pause": plt.axes([0.05, 0.05, 0.1, 0.05]),
    "resume": plt.axes([0.17, 0.05, 0.1, 0.05]),
    "stop": plt.axes([0.29, 0.05, 0.1, 0.05]),
}

# === Buttons ===
pause_button = Button(button_axs["pause"], "Pause", color='orange', hovercolor='red')
resume_button = Button(button_axs["resume"], "Resume", color='lightgreen', hovercolor='green')
stop_button = Button(button_axs["stop"], "Stop", color='red', hovercolor='darkred')

# === Button Callbacks ===
def on_pause(event):
    err = robot.PauseMotion()
    print("Pause:", err)

def on_resume(event):
    err = robot.ResumeMotion()
    print("Resume:", err)

def on_stop(event):
    err = robot.StopMotion()
    print("Stop:", err)
    ret = robot.ResetAllError()
    print("Reset Errors:", ret)

pause_button.on_clicked(on_pause)
resume_button.on_clicked(on_resume)
stop_button.on_clicked(on_stop)

# === Low-pass filter vars ===
filtered_force = np.zeros(3)
filtered_torque = np.zeros(3)
prev_F_res = 0.0

# === Main Loop with Clean Exit ===
try:
    while True:
        # Update sliders
        force_to_mm = sliders["force_to_mm"].val
        torque_to_deg = sliders["torque_to_deg"].val
        max_move_mm = sliders["max_move_mm"].val
        max_rot_deg = sliders["max_rot_deg"].val
        min_force_threshold = sliders["min_force_threshold"].val
        alpha = sliders["alpha"].val

        data = robot.FT_GetForceTorqueOrigin()

        if data and len(data[1]) == 6:
            Fx_raw, Fy_raw, Fz_raw, Mx_raw, My_raw, Mz_raw = data[1]

            filtered_force = alpha * filtered_force + (1 - alpha) * np.array([Fx_raw, Fy_raw, Fz_raw])
            filtered_torque = alpha * filtered_torque + (1 - alpha) * np.array([Mx_raw, My_raw, Mz_raw])
            Fx, Fy, Fz = filtered_force
            Mx, My, Mz = filtered_torque

            # Translation only
            dx = -Fz * force_to_mm
            dy = Fy * force_to_mm
            dz = Fx * force_to_mm

            dx = np.clip(dx, -max_move_mm, max_move_mm)
            dy = np.clip(dy, -max_move_mm, max_move_mm)
            dz = np.clip(dz, -max_move_mm, max_move_mm)

            F_res = np.linalg.norm([Fx, Fy, Fz])
            M_res = np.linalg.norm([Mx, My, Mz])

            vel = max(5, min(100, int(max(abs(dx), abs(dy), abs(dz)) * 10)))

            if abs(F_res - prev_F_res) > min_force_threshold:
                pose[0] += dx
                pose[1] += dy
                pose[2] += dz
                pose[3], pose[4], pose[5] = initial_orientation  # fixed orientation

                ret = robot.MoveL(pose, tool, user, vel=3.0)
                print(f"Moved: ΔX={dx:.2f} ΔY={dy:.2f} ΔZ={dz:.2f} | Orientation: Fixed | Vel={vel} | Code={ret}")

            prev_F_res = F_res

            # Plot
            ax.cla()
            ax.set_xlim([-50, 50])
            ax.set_ylim([-50, 50])
            ax.set_zlim([-50, 50])
            ax.set_xlabel('X (←Fz)')
            ax.set_ylabel('Y (Fy)')
            ax.set_zlabel('Z (Fx)')

            force_color = cmap(plt.Normalize(vmin=0, vmax=100)(F_res))
            ax.quiver(0, 0, 0, -Fz, Fy, Fx, color=force_color, length=F_res/10, normalize=False, linewidth=2)
            ax.text(-Fz, Fy, Fx, f"F({Fx:.1f}, {Fy:.1f}, {Fz:.1f})", color='black')

            ax.quiver(0, 0, 0, Mx, My, Mz, color='green', length=M_res/10, normalize=False, linewidth=1.5)
            ax.text(Mx, My, Mz, f"M({Mx:.1f}, {My:.1f}, {Mz:.1f})", color='green')

            ax.set_title(f"Force Mag: {F_res:.2f} N | Torque Mag: {M_res:.2f} Nm")

            plt.pause(0.01)

        else:
            print("Invalid FT data")

        time.sleep(0.001)

except KeyboardInterrupt:
    print("\nInterrupted by user. Stopping safely...")
    robot.StopMotion()
    robot.ResetAllError()
    plt.close(fig)
