import Robot
import time

# Connect to Robot
robot = Robot.RPC('192.168.58.2')

# Initialize Force-Torque sensor
company = 24  # Kunwit Tech
device = 0
robot.FT_SetConfig(company, device)
robot.FT_Activate(0)  # Reset
time.sleep(1)
robot.FT_Activate(1)  # Activate
time.sleep(1)
robot.SetLoadWeight(0, 0.0)
robot.SetLoadCoord(0.0, 0.0, 0.0)
robot.FT_SetZero(0)
time.sleep(1)
robot.FT_SetZero(1)
time.sleep(1)

# Get Initial Pose in mm
initial_pos = robot.GetActualToolFlangePose()
print("Initial Pose:", initial_pos[1])

# Admittance Parameters (mm units)
M = 0.4     # kg
B = 150.0   # N·s/m → 800 N·s/m = 0.8 N·s/mm
K = 0.3     # N/mm
dt = 0.01  # seconds
tool = 0
user = 0




position_threshold = 0.5  # mm
threshold = 1.6  # Force threshold in Newtons
min_displacement = 2.0  # minimum displacement in mm after threshold is crossed
scale_per_0_1N = 2.0     # mm displacement added per 0.1 N above threshold
max_disp = 1000.0  # max displacement limit in mm

# Initialize per-axis state variables outside the loop:
disp = [0.0, 0.0, 0.0]      # displacement for X, Y, Z (mm)
vel = [0.0, 0.0, 0.0]       # velocity for X, Y, Z (mm/s)
acc = [0.0, 0.0, 0.0]       # acceleration for X, Y, Z (mm/s²)
prev_disp = [0.0, 0.0, 0.0] # previous displacement for X, Y, Z (mm)

Kp = 40.0
Kd = 10.0
dt = 0.01

try:
    while True:
        ft = robot.FT_GetForceTorqueRCS()
        forces = [-ft[1][0], ft[1][1], -ft[1][2]]  # X, Y, Z force in N (inverted as before)

        # Calculate new acceleration, velocity, displacement per axis
        for i in range(3):
            F_ext = forces[i]

            if abs(F_ext) > threshold:
                force_over = abs(F_ext) - threshold
                target_disp = min_displacement + force_over * 20.0
                target_disp = target_disp if F_ext > 0 else -target_disp

                error = target_disp - disp[i]
                acc[i] = Kp * error - Kd * vel[i]
            else:
                # Smooth return to zero
                acc[i] = -Kp * disp[i] - Kd * vel[i]

            vel[i] += acc[i] * dt
            disp[i] += vel[i] * dt
            disp[i] = max(min(disp[i], max_disp), -max_disp)

        # Calculate magnitude of velocity vector for MoveCart velocity scaling
        vel_mag = (vel[0]**2 + vel[1]**2 + vel[2]**2)**0.5
        base_vel = 5.0
        max_vel = 100.0
        move_vel = base_vel + min(vel_mag * 5.0, max_vel - base_vel)

        # Construct target position adding displacement to initial pose (mm units)
        target_pos = [
            initial_pos[1][0] + disp[0],
            initial_pos[1][1] + disp[1],
            initial_pos[1][2] + disp[2],
            initial_pos[1][3],
            initial_pos[1][4],
            initial_pos[1][5]
        ]

        # Check if displacement changed enough to move robot
        if any(abs(disp[i] - prev_disp[i]) > 0.5 for i in range(3)):
            err = robot.MoveCart(target_pos, tool, user, vel=move_vel, acc=0.0, ovl=100.0, blendT=1.0)
            print(f"F_x: {forces[0]:.2f} N | F_y: {forces[1]:.2f} N | F_z: {forces[2]:.2f} N | "
                  f"x: {disp[0]:.2f} mm | y: {disp[1]:.2f} mm | z: {disp[2]:.2f} mm | vel: {move_vel:.2f} mm/s | MoveCart error: {err}")
        else:
            print(f"Holding | x: {disp[0]:.2f} mm | y: {disp[1]:.2f} mm | z: {disp[2]:.2f} mm | vel: {move_vel:.2f} mm/s")

        # Update previous displacement
        prev_disp = disp.copy()

        time.sleep(dt)
        ret = robot.StopMotion() #Stop motion
        print("Terminating motion: error code", ret)

except KeyboardInterrupt:
    print("Admittance control stopped.")

